<section class="section section-newsletter background_cover" style="background: linear-gradient(rgba(131, 152, 141, 0.7),rgba(131, 152, 141, 0.7)), url('https://upload.wikimedia.org/wikipedia/commons/1/14/Un_super_paysage.jpeg');">

    <div class="container">
        <h2 class="text-center"><p>recevez dans vos boîtes mail nos 3 vidéos astuces SILENCE. </p></h2>
    </div>

</section>   