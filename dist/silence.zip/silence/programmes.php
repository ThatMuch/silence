<?php
/**
 * Template for Programmes Page
 *
 * @author      ThatMuch
 * @version     0.1.0
 * @since       silence_1.0.0
 * @package     silence
 *  Template Name: Programmes
 * Header
 */

get_header();

?>

<div class="section__area border-bottom pb-150">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 mx-auto">
				<h2 class="m-title text-center fw-normal">Nos formatrices et formateurs en prise de parole seront à vos côté tout au long de votre parcours de formation innovant ! </h2>
			</div>
		</div>
	</div>
</div>
